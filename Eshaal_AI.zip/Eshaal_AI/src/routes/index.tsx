import { createFileRoute } from "@tanstack/react-router";
import { Navbar } from "@/components/Navbar";
import { HeroSection } from "@/components/HeroSection";
import { AboutSection } from "@/components/AboutSection";
import { ProjectsSection } from "@/components/ProjectsSection";
import { SkillsSection } from "@/components/SkillsSection";
import { ExperienceSection } from "@/components/ExperienceSection";
import { CertificationsSection } from "@/components/CertificationsSection";
import { AIAgentSection } from "@/components/AIAgentSection";
import { FutureWorkSection } from "@/components/FutureWorkSection";
import { ContactSection } from "@/components/ContactSection";
import { Footer } from "@/components/Footer";
import { SITE } from "@/data/portfolio";

const TITLE = "Eshaal Malik | AI & Machine Learning Student";
const DESCRIPTION =
  "Portfolio of Eshaal Malik, an AI and Machine Learning student building practical machine learning, data science, and artificial intelligence projects with Python.";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "profile" },
      { property: "og:url", content: "/" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: TITLE },
      { name: "twitter:description", content: DESCRIPTION },
    ],
    links: [{ rel: "canonical", href: "/" }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Person",
          name: SITE.name,
          jobTitle: SITE.title,
          email: `mailto:${SITE.email}`,
          address: { "@type": "PostalAddress", addressLocality: "Karachi", addressCountry: "PK" },
          sameAs: [SITE.github, SITE.linkedin],
          knowsAbout: [
            "Machine Learning",
            "Artificial Intelligence",
            "Data Science",
            "Python",
            "Computer Vision",
          ],
        }),
      },
    ],
  }),
});

function Index() {
  return (
    <>
      <Navbar />
      <main>
        <HeroSection />
        <AboutSection />
        <ProjectsSection />
        <SkillsSection />
        <ExperienceSection />
        <CertificationsSection />
        <AIAgentSection />
        <FutureWorkSection />
        <ContactSection />
      </main>
      <Footer />
    </>
  );
}
