import searchRankingImg from "@/assets/search-ranking.png.asset.json";
import aqiPakImg from "@/assets/aqi-pak.png.asset.json";
import neurolynkImg from "@/assets/neurolynk.png.asset.json";
import bwRgbImg from "@/assets/bw-rgb.png.asset.json";
import financeTrackerImg from "@/assets/finance-tracker.png.asset.json";
import miniGptImg from "@/assets/mini-gpt.png.asset.json";
import stockPredictionImg from "@/assets/stock-prediction.png.asset.json";
import carPriceImg from "@/assets/car-price.png.asset.json";
import diadecodesImg from "@/assets/diadecodes.png.asset.json";
import gymManagementImg from "@/assets/gym-management.png.asset.json";

// Central configuration & content for the Eshaal Malik portfolio.
// Keep ALL external links and content here — never hard-code URLs in components.

export const SITE = {
  name: "Eshaal Malik",
  title: "AI & Machine Learning Student",
  positioning: "Python · Machine Learning · AI",
  tagline: "Building practical machine learning and AI systems with Python.",
  location: "Karachi, Pakistan",
  email: "eshaalmzaa@gmail.com",
  github: "https://github.com/Eshaal356",
  linkedin: "https://www.linkedin.com/in/eshaal-malik-556264369/",
  cv: "/cv.pdf",
  /** Replace BOOKING_URL_HERE with a real scheduling link to enable the button. */
  bookingUrl: "BOOKING_URL_HERE",
} as const;

export const isBookingConfigured = SITE.bookingUrl !== "BOOKING_URL_HERE";

export interface NavItem {
  label: string;
  id: string;
}

export const NAV_ITEMS: NavItem[] = [
  { label: "About", id: "about" },
  { label: "Projects", id: "projects" },
  { label: "Skills", id: "skills" },
  { label: "Experience", id: "experience" },
  { label: "Certifications", id: "certifications" },
  { label: "AI Agent", id: "ai-agent" },
  { label: "Future Work", id: "future" },
  { label: "Contact", id: "contact" },
];

export interface Project {
  id: string;
  index: string;
  name: string;
  description: string;
  details?: string[];
  result?: string;
  tech: string[];
  live?: string;
  github: string;
  featured?: boolean;
  /** Project cover image (imported asset). */
  image?: string;
  /** Accessible description of the cover image. */
  imageAlt?: string;
}

export const PROJECTS: Project[] = [
  {
    id: "search-ranking",
    image: searchRankingImg.url,
    imageAlt:
      "Infographic for the Google Search Ranking project: search metrics, a laptop dashboard of page priority scores, and a machine-learning workflow.",
    index: "01",
    name: "Google Search Ranking & Discoverability",
    description:
      "A machine-learning project focused on identifying content pages that should be prioritized for optimization using historical search performance, content freshness, engagement, and search visibility.",
    tech: ["Python", "Pandas", "Scikit-learn", "Random Forest", "Machine Learning"],
    live: "https://eshaal356.github.io/flyrank-ml-internship/",
    github: "https://github.com/Eshaal356",
    featured: true,
  },
  {
    id: "aqi-pak",
    image: aqiPakImg.url,
    imageAlt:
      "AQI-PAK command centre dashboard: map of Pakistan with live air-quality values, forecast charts and pollutant breakdowns.",
    index: "02",
    name: "AQI-PAK Strategic Command",
    description:
      "An AI-driven air-quality forecasting system for major cities of Pakistan using ensemble machine learning models.",
    details: [
      "Processed and analyzed 123,000+ hourly environmental records",
      "Data covered environmental and meteorological information from 2021–2024",
      "Engineered 112+ features",
      "Used temporal cycles and lag-based forecasting signals",
      "Built an ensemble pipeline using XGBoost, LightGBM, and Random Forest",
      "Developed interactive Plotly and Streamlit dashboards",
      "Implemented 24-hour, 48-hour and 72-hour forecasting windows",
    ],
    result: "94%+ prediction accuracy",
    tech: [
      "Python",
      "XGBoost",
      "LightGBM",
      "Random Forest",
      "Pandas",
      "Plotly",
      "Streamlit",
      "Machine Learning",
    ],
    github: "https://github.com/Eshaal356/AQI-PAK-STRATEGIC-COMMAND",
    featured: true,
  },
  {
    id: "neurolynk",
    image: neurolynkImg.url,
    imageAlt:
      "NeuroLynk logo: a gradient brain icon inside a stylised globe.",
    index: "03",
    name: "NeuroLynk",
    description:
      "A modular conversational AI assistant exploring prompt engineering, response management, conversational memory, and AI workflow design.",
    details: [
      "Conversational AI",
      "Prompt engineering",
      "Response management",
      "AI workflow design",
      "LLM concepts",
      "Contextual understanding",
    ],
    tech: ["Conversational AI", "Prompt Engineering", "LLM Concepts", "AI Workflow Design"],
    live: "https://neurolynk-multilingual-st-819.created.app/",
    github: "https://github.com/Eshaal356",
    featured: true,
  },
  {
    id: "bw-rgb",
    image: bwRgbImg.url,
    imageAlt:
      "Before-and-after comparison of black-and-white portraits colourised into realistic colour versions.",
    index: "04",
    name: "BW to RGB — AI Image Colorization System",
    description:
      "A deep learning-based image colorization system for converting black-and-white images into realistic RGB outputs.",
    details: [
      "Computer vision",
      "Image preprocessing",
      "Image restoration",
      "Deep learning",
      "RGB reconstruction",
      "Edge preservation",
      "Research-based colorization approaches",
    ],
    tech: ["Python", "OpenCV", "Deep Learning", "Computer Vision"],
    github: "https://github.com/Eshaal356/BW-TO-RGB",
  },
  {
    id: "finance-tracker",
    image: financeTrackerImg.url,
    imageAlt:
      "Personal Finance Tracker dashboard on a laptop and phone with income, expense and monthly trend charts.",
    index: "05",
    name: "Personal Finance Tracker",
    description:
      "A Python and Streamlit application for tracking and visualizing income and expense trends.",
    tech: ["Python", "Streamlit", "Pandas"],
    github:
      "https://github.com/Eshaal356/Personal-Finance-Tracking-Application-using-Python-and-Streamlit",
  },
  {
    id: "mini-gpt",
    image: miniGptImg.url,
    imageAlt:
      "Mini GPT infographic: a transformer block diagram beside a conversational chat interface.",
    index: "06",
    name: "Mini GPT",
    description:
      "A lightweight GPT-style conversational AI system focused on text generation, contextual response handling, prompt-based interaction workflows, and exploration of transformer-based architectures.",
    tech: ["Python", "Generative AI", "LLM concepts", "Prompt Engineering"],
    github: "https://github.com/Eshaal356/Mini-GPT",
  },
  {
    id: "stock-prediction",
    image: stockPredictionImg.url,
    imageAlt:
      "Stock price prediction chart with an upward candlestick trend and an LSTM model diagram.",
    index: "07",
    name: "Stock Price Prediction",
    description:
      "A time-series forecasting project using historical financial data, time-based feature engineering, machine learning, and LSTM-based modeling.",
    tech: ["Python", "Machine Learning", "LSTM", "Time-Series Forecasting", "Data Analysis"],
    github: "https://github.com/Eshaal356/Netflix-Stock-Prediction-Dataset",
  },
  {
    id: "car-price",
    image: carPriceImg.url,
    imageAlt:
      "3D car analysis visualisation: a white sedan on a pedestal surrounded by 3D scatter plots and price metrics.",
    index: "08",
    name: "3D Car Analysis & Price Prediction",
    description:
      "A regression and data-analysis project focused on automobile price prediction, feature relationships, and 3D visualization.",
    tech: ["Python", "Regression", "Data Analysis", "3D Visualization", "Machine Learning"],
    github: "https://github.com/Eshaal356/codealpha_Car-Price-Prediction",
  },
  {
    id: "diadecodes",
    image: diadecodesImg.url,
    imageAlt:
      "DiaDecodes infographic: confusion matrix, ROC curve and feature-importance chart for the diabetes model.",
    index: "09",
    name: "DiaDecodes — Diabetes Prediction Model",
    description:
      "A classification project using the PIMA Diabetes Dataset involving exploratory data analysis, preprocessing, feature engineering, and model evaluation.",
    tech: ["Python", "Pandas", "Machine Learning", "Classification", "Data Analysis"],
    github: "https://github.com/Eshaal356/DiaDecodes",
  },
  {
    id: "gym-management",
    image: gymManagementImg.url,
    imageAlt:
      "Gym Management System infographic: admin, trainer and member dashboards with member list and attendance table.",
    index: "10",
    name: "GYM Management System",
    description:
      "A complete Python-based management system for gyms and fitness centers with role-based workflows for administrators, trainers, and members. Also includes a simple keyword-based gym chatbot.",
    details: [
      "Admin: member management, trainer management, class schedules, attendance, payments, maintenance, equipment management, reports",
      "Trainer: training programs, assigned tasks, schedules, member progress, personal training sessions, maintenance requests",
      "Member: payments, trainer/class booking, schedules, progress, attendance, feedback, profile management",
    ],
    tech: ["Python 3", "Pandas", "Matplotlib", "getpass", "os", "datetime"],
    github: "https://github.com/Eshaal356/GYM-Management-System",
  },
];

export interface SkillCategory {
  title: string;
  items: string[];
}

export const SKILLS: SkillCategory[] = [
  {
    title: "Programming",
    items: ["Python", "Data processing", "Scripting", "Automation", "AI workflows"],
  },
  {
    title: "Data Processing & Quality",
    items: [
      "Pandas",
      "NumPy",
      "Data cleaning",
      "Data validation",
      "Consistency checks",
      "CSV/JSON handling",
    ],
  },
  {
    title: "Machine Learning",
    items: [
      "Supervised Learning",
      "Classification",
      "Regression",
      "Time-Series Forecasting",
      "Feature Engineering",
      "Model Evaluation",
      "Deep Learning fundamentals",
      "Scikit-learn",
      "XGBoost",
      "LightGBM",
      "Random Forest",
    ],
  },
  {
    title: "Generative AI & LLMs",
    items: [
      "Prompt Engineering",
      "Conversational AI",
      "LLM workflows",
      "Contextual response handling",
      "Lightweight GPT-style architectures",
      "AI Agents",
      "RAG",
    ],
  },
  {
    title: "Computer Vision",
    items: [
      "OpenCV",
      "Image preprocessing",
      "Feature extraction",
      "Image colorization",
      "Image restoration workflows",
    ],
  },
  {
    title: "Analytics",
    items: [
      "Exploratory Data Analysis",
      "Metrics definition",
      "Statistical reasoning",
      "Forecasting analysis",
    ],
  },
  {
    title: "Visualization & Tools",
    items: [
      "Power BI",
      "Plotly",
      "Matplotlib",
      "Streamlit",
      "Jupyter Notebook",
      "Google Colab",
    ],
  },
  {
    title: "Development & Collaboration",
    items: [
      "Git",
      "GitHub",
      "Documentation",
      "Remote teamwork",
      "Debugging",
      "Feedback-driven iteration",
    ],
  },
];

export interface ExperienceItem {
  role: string;
  company: string;
  status: string;
  points: string[];
}

export const EXPERIENCE: ExperienceItem[] = [
  {
    role: "Data Science Intern",
    company: "SyntecxHub",
    status: "Remote | Completed",
    points: [
      "Performed data cleaning, validation, and preprocessing on structured datasets",
      "Conducted exploratory data analysis",
      "Identified inconsistencies, missing values, and data errors",
      "Assisted with machine learning model development, evaluation, and testing",
      "Documented data pipelines and model processes",
      "Worked independently on assigned tasks",
      "Contributed to production-oriented AI projects",
      "Participated in team reviews",
    ],
  },
  {
    role: "Data Science Intern",
    company: "Arch Technologies",
    status: "Remote | Completed",
    points: [
      "Selected through skills-based screening",
      "Contributed to data collection",
      "Performed preprocessing and analysis on real-world datasets",
      "Supported supervised learning models",
      "Supported evaluation tasks",
      "Worked in a collaborative remote environment",
      "Contributed to data quality and processing efficiency",
    ],
  },
  {
    role: "Machine Learning Intern",
    company: "FutureXcel",
    status: "Remote | Completed",
    points: [
      "Worked on practical ML tasks",
      "Performed data preprocessing",
      "Worked on model building",
      "Gained experience with supervised learning workflows",
      "Improved dataset quality through preprocessing techniques",
    ],
  },
  {
    role: "Data Science Intern",
    company: "Code Alpha",
    status: "Remote | Completed",
    points: [
      "Practical Python-based machine learning implementations",
      "Assisted in model building",
      "Assisted in evaluation",
      "Worked on data-driven project development",
      "Collaborated with team members",
      "Completed assigned tasks independently",
    ],
  },
];

export const EDUCATION = {
  qualification: "Intermediate, Computer Science",
  institution: "Government Degree College (SRE Majeed)",
  status: "Ongoing",
  description:
    "Current studies alongside self-directed work in Python, machine learning, data science and artificial intelligence.",
};

export interface CertificationGroup {
  title: string;
  items: string[];
}

export const CERTIFICATIONS: CertificationGroup[] = [
  {
    title: "Traditional Training",
    items: [
      "AI & Data Science — Saylani Mass IT Training",
      "Data Science, Machine Learning & AI — eHunarMand Pakistan",
      "Python for Data Science — IBM Skills Network",
      "AI Prompt Engineering — IBM Cognitive Class",
      "Power BI Fundamentals — Cambridge International Qualification",
      "Introduction to Data Science Job Simulation — Commonwealth Bank / Forage",
    ],
  },
  {
    title: "Anthropic / AI Learning",
    items: [
      "AI Fluency Foundations",
      "AI Fluency",
      "AI Fluency for Business",
      "AI Fluency for Students",
      "AI Fluency for Nonprofits",
      "AI Policy: AI Capabilities & Limitations",
      "Claude 101",
      "Claude Platform 101",
      "Claude with the Anthropic API",
      "Claude with Google Vertex AI",
      "Claude with Amazon Bedrock",
      "Introduction to Claude Code",
      "Introduction to Model Context Protocol (MCP)",
      "Model Context Protocol: Advanced Topics",
      "Introduction to Agent Skills",
      "Introduction to Claude Cowork",
      "AI Capabilities and Limitations",
      "AI Fluency for Small Businesses",
      "AI Fluency for Educators",
      "Teaching AI Fluency",
      "AI Fluency for Builders",
      "Claude Code 101",
      "Claude Code in Action",
      "Building with the Claude API",
      "Introduction to Subagents",
    ],
  },
];

export const FUTURE_WORK = [
  {
    title: "ML Experiments",
    description: "Further supervised and deep learning experiments across new datasets.",
  },
  {
    title: "Applied AI Systems",
    description: "Practical AI applications built around real, usable interfaces.",
  },
  {
    title: "Research Projects",
    description: "Structured exploration of machine learning and AI research topics.",
  },
  {
    title: "Capstone Work",
    description: "A larger end-to-end machine learning and AI capstone project.",
  },
];

export const AI_SUGGESTED_QUESTIONS = [
  "Who is Eshaal?",
  "What projects has Eshaal built?",
  "Explain the Google Search Ranking project.",
  "What ML technologies does Eshaal use?",
  "What internships has Eshaal completed?",
  "What certifications has Eshaal completed?",
  "How can I contact Eshaal?",
];
