import { motion, useReducedMotion } from "framer-motion";
import characterImg from "@/assets/eshaal-3d.png";
import { Magnet } from "./Magnet";

export function ThreeDCharacter() {
  const reduce = useReducedMotion();

  return (
    <motion.div
      className="pointer-events-none absolute bottom-0 left-1/2 z-10 -translate-x-1/2 translate-y-[8%]"
      initial={reduce ? { opacity: 1 } : { opacity: 0, y: 30, scale: 0.96 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ delay: 0.6, duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
    >
      <Magnet padding={150} strength={3}>
        <img
          src={characterImg}
          alt="Stylized 3D character render representing Eshaal Malik's personal digital identity"
          width={1024}
          height={1280}
          className="w-[195px] object-contain drop-shadow-[0_30px_60px_rgba(0,0,0,0.6)] sm:w-[290px] md:w-[340px] lg:w-[400px]"
        />
      </Magnet>

    </motion.div>
  );
}
