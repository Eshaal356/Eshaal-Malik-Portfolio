import { SITE, isBookingConfigured } from "@/data/portfolio";

export function Footer() {
  return (
    <footer className="border-t border-white/10 bg-hero py-12">
      <div className="mx-auto flex max-w-7xl flex-col gap-8 px-5 lg:flex-row lg:items-end lg:justify-between lg:px-8">
        <div>
          <p className="font-display text-2xl font-black uppercase tracking-tight text-white">
            {SITE.name}
          </p>
          <p className="mt-1 text-xs font-medium uppercase tracking-[0.22em] text-white/45">
            AI &amp; Machine Learning
          </p>
        </div>

        <nav aria-label="Footer">
          <ul className="flex flex-wrap gap-x-6 gap-y-3 text-sm text-white/60">
            <li>
              <a
                href={SITE.github}
                target="_blank"
                rel="noreferrer noopener"
                className="hover:text-white"
              >
                GitHub
              </a>
            </li>
            <li>
              <a
                href={SITE.linkedin}
                target="_blank"
                rel="noreferrer noopener"
                className="hover:text-white"
              >
                LinkedIn
              </a>
            </li>
            <li>
              <a href={`mailto:${SITE.email}`} className="hover:text-white">
                Email
              </a>
            </li>
            <li>
              <a href={SITE.cv} download className="hover:text-white">
                CV
              </a>
            </li>
            <li>
              {isBookingConfigured ? (
                <a
                  href={SITE.bookingUrl}
                  target="_blank"
                  rel="noreferrer noopener"
                  className="hover:text-white"
                >
                  Book a Meeting
                </a>
              ) : (
                <span className="text-white/30">Booking link coming soon</span>
              )}
            </li>
          </ul>
        </nav>
      </div>

      <p className="mx-auto mt-10 max-w-7xl px-5 text-xs text-white/35 lg:px-8">
        © 2026 {SITE.name}. All rights reserved.
      </p>
    </footer>
  );
}
