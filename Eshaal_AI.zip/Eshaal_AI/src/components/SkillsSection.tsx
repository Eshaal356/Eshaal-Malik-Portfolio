import { SKILLS } from "@/data/portfolio";
import { FadeIn } from "./FadeIn";

export function SkillsSection() {
  return (
    <section id="skills" className="border-b border-border bg-background py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <FadeIn>
          <p className="section-eyebrow">Skills</p>
          <h2 className="mt-4 font-display text-3xl font-black tracking-tight text-foreground sm:text-4xl lg:text-5xl">
            Tools and Techniques
          </h2>
        </FadeIn>

        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {SKILLS.map((category, i) => (
            <FadeIn key={category.title} delay={(i % 4) * 0.05}>
              <div className="h-full rounded-2xl border border-border p-6 transition-colors hover:border-foreground/25">
                <h3 className="font-display text-sm font-bold uppercase tracking-[0.14em] text-foreground">
                  {category.title}
                </h3>
                <ul className="mt-4 flex flex-wrap gap-2">
                  {category.items.map((item) => (
                    <li key={item} className="badge">
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </FadeIn>
          ))}
        </div>
      </div>
    </section>
  );
}
