import { useState } from "react";
import { ChevronDown, Award } from "lucide-react";
import { CERTIFICATIONS } from "@/data/portfolio";
import { FadeIn } from "./FadeIn";

export function CertificationsSection() {
  const [open, setOpen] = useState<string | null>(CERTIFICATIONS[0]?.title ?? null);

  return (
    <section
      id="certifications"
      className="border-b border-border bg-background py-24 lg:py-32"
    >
      <div className="mx-auto max-w-4xl px-5 lg:px-8">
        <FadeIn>
          <p className="section-eyebrow">Certifications</p>
          <h2 className="mt-4 font-display text-3xl font-black tracking-tight text-foreground sm:text-4xl lg:text-5xl">
            Training &amp; Courses
          </h2>
        </FadeIn>

        <div className="mt-10 space-y-4">
          {CERTIFICATIONS.map((group, i) => {
            const isOpen = open === group.title;
            return (
              <FadeIn key={group.title} delay={i * 0.05}>
                <div className="overflow-hidden rounded-2xl border border-border">
                  <button
                    onClick={() => setOpen(isOpen ? null : group.title)}
                    aria-expanded={isOpen}
                    className="flex w-full items-center justify-between gap-4 px-6 py-5 text-left transition-colors hover:bg-secondary/60"
                  >
                    <span className="font-display text-base font-bold tracking-tight text-foreground">
                      {group.title}
                      <span className="ml-2 text-xs font-medium text-muted-foreground">
                        ({group.items.length})
                      </span>
                    </span>
                    <ChevronDown
                      aria-hidden="true"
                      className={`h-4 w-4 shrink-0 text-muted-foreground transition-transform ${
                        isOpen ? "rotate-180" : ""
                      }`}
                    />
                  </button>
                  {isOpen ? (
                    <ul className="grid gap-2 border-t border-border px-6 py-5 sm:grid-cols-2">
                      {group.items.map((item) => (
                        <li
                          key={item}
                          className="flex items-start gap-2 text-sm text-muted-foreground"
                        >
                          <Award
                            className="mt-0.5 h-3.5 w-3.5 shrink-0 text-accent-ink"
                            aria-hidden="true"
                          />
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  ) : null}
                </div>
              </FadeIn>
            );
          })}
        </div>
      </div>
    </section>
  );
}
