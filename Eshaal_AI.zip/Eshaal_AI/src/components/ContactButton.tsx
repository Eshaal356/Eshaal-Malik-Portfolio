import { CalendarDays } from "lucide-react";
import { SITE, isBookingConfigured } from "@/data/portfolio";

interface Props {
  variant?: "light" | "dark";
  className?: string;
}

/** Book-a-meeting control. Disabled until a real booking URL is configured. */
export function ContactButton({ variant = "light", className = "" }: Props) {
  const base =
    "inline-flex items-center gap-2 rounded-full px-5 py-3 text-sm font-semibold transition-colors";

  if (!isBookingConfigured) {
    return (
      <span
        aria-disabled="true"
        title="A booking link has not been configured yet"
        className={`${base} cursor-not-allowed border ${
          variant === "dark"
            ? "border-white/20 text-white/40"
            : "border-border text-muted-foreground"
        } ${className}`}
      >
        <CalendarDays className="h-4 w-4" aria-hidden="true" />
        Booking link coming soon
      </span>
    );
  }

  return (
    <a
      href={SITE.bookingUrl}
      target="_blank"
      rel="noreferrer noopener"
      className={`${base} border ${
        variant === "dark"
          ? "border-white/25 text-white hover:bg-white/10"
          : "border-border text-foreground hover:bg-secondary"
      } ${className}`}
    >
      <CalendarDays className="h-4 w-4" aria-hidden="true" />
      Book a Meeting
    </a>
  );
}
