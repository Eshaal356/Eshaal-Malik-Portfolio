import { motion, useReducedMotion } from "framer-motion";
import { ArrowRight, Download, Github, Linkedin, MapPin, Sparkles } from "lucide-react";
import { SITE } from "@/data/portfolio";
import { ThreeDCharacter } from "./ThreeDCharacter";

function scrollTo(id: string) {
  document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
}

export function HeroSection() {
  const reduce = useReducedMotion();
  const fade = (delay: number) => ({
    initial: reduce ? { opacity: 1 } : { opacity: 0, y: 16 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.8, delay, ease: [0.22, 1, 0.36, 1] as const },
  });

  return (
    <section
      id="hero"
      className="relative flex min-h-[100svh] w-full flex-col overflow-hidden bg-hero"
    >
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_50%_120%,rgba(187,204,215,0.14),transparent_60%)]" />

      <div className="relative flex flex-1 flex-col justify-between pb-6 pt-24 sm:pb-10">
        <motion.p
          {...fade(0.1)}
          className="mx-auto flex w-fit items-center gap-2 rounded-full border border-white/15 px-4 py-1.5 text-[11px] font-medium uppercase tracking-[0.22em] text-white/70"
        >
          <Sparkles className="h-3 w-3" aria-hidden="true" />
          {SITE.positioning}
        </motion.p>

        <h1 className="sr-only">Eshaal Malik — AI &amp; Machine Learning Student</h1>

        <div className="relative mt-10 flex items-end justify-center">
          <motion.span
            {...fade(0.2)}
            aria-hidden="true"
            className="hero-heading block w-full select-none text-center font-display text-[21vw] font-black leading-[0.9] tracking-tight sm:text-[14vw] sm:leading-none md:text-[15vw] lg:text-[17vw]"
          >
            Hi, i&apos;m Eshaal
          </motion.span>
          <ThreeDCharacter />
        </div>
      </div>


      <div className="relative z-20 border-t border-white/10 bg-hero/60 backdrop-blur-sm">
        <div className="mx-auto flex max-w-7xl flex-col gap-6 px-5 py-7 lg:flex-row lg:items-center lg:justify-between lg:px-8">
          <motion.div {...fade(0.9)} className="max-w-md">
            <p className="font-display text-xs font-bold uppercase tracking-[0.22em] text-white/60">
              {SITE.title}
            </p>
            <p className="mt-2 text-sm leading-relaxed text-white/80">{SITE.tagline}</p>
            <p className="mt-2 flex items-center gap-1.5 text-xs text-white/50">
              <MapPin className="h-3.5 w-3.5" aria-hidden="true" />
              {SITE.location}
            </p>
          </motion.div>

          <motion.div {...fade(1)} className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => scrollTo("projects")}
              className="inline-flex items-center gap-2 rounded-full bg-white px-5 py-3 text-sm font-semibold text-hero transition-transform hover:-translate-y-0.5"
            >
              Explore My Projects
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </button>
            <button
              onClick={() => scrollTo("ai-agent")}
              className="rounded-full border border-white/25 px-5 py-3 text-sm font-semibold text-white transition-colors hover:bg-white/10"
            >
              Try Eshaal AI
            </button>
            <a
              href={SITE.cv}
              download
              className="inline-flex items-center gap-2 rounded-full border border-white/25 px-5 py-3 text-sm font-semibold text-white transition-colors hover:bg-white/10"
            >
              <Download className="h-4 w-4" aria-hidden="true" />
              Download CV
            </a>
            <div className="flex items-center gap-2">
              <a
                href={SITE.github}
                target="_blank"
                rel="noreferrer noopener"
                aria-label="Eshaal Malik on GitHub"
                className="inline-flex h-11 w-11 items-center justify-center rounded-full border border-white/20 text-white transition-colors hover:bg-white/10"
              >
                <Github className="h-4 w-4" aria-hidden="true" />
              </a>
              <a
                href={SITE.linkedin}
                target="_blank"
                rel="noreferrer noopener"
                aria-label="Eshaal Malik on LinkedIn"
                className="inline-flex h-11 w-11 items-center justify-center rounded-full border border-white/20 text-white transition-colors hover:bg-white/10"
              >
                <Linkedin className="h-4 w-4" aria-hidden="true" />
              </a>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
