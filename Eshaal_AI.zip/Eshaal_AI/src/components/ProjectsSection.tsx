import { useState } from "react";
import { ArrowUpRight } from "lucide-react";
import { PROJECTS, SITE } from "@/data/portfolio";
import { ProjectCard } from "./ProjectCard";
import { FadeIn } from "./FadeIn";

export function ProjectsSection() {
  const [showAll, setShowAll] = useState(false);
  const featured = PROJECTS.filter((p) => p.featured);
  const rest = PROJECTS.filter((p) => !p.featured);
  const visible = showAll ? rest : rest.slice(0, 3);

  return (
    <section id="projects" className="border-b border-border bg-secondary/30 py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <FadeIn>
          <p className="section-eyebrow">Projects</p>
          <h2 className="mt-4 font-display text-3xl font-black tracking-tight text-foreground sm:text-4xl lg:text-5xl">
            Selected Work
          </h2>
          <p className="mt-4 max-w-xl text-[15px] leading-relaxed text-muted-foreground">
            Machine learning, data science and AI projects built with Python.
          </p>
        </FadeIn>

        <div className="mt-12 space-y-6">
          {featured.map((project, i) => (
            <FadeIn key={project.id} delay={i * 0.05}>
              <ProjectCard project={project} featured />
            </FadeIn>
          ))}
        </div>

        <div className="mt-6 grid gap-6 md:grid-cols-2 xl:grid-cols-3">
          {visible.map((project, i) => (
            <FadeIn key={project.id} delay={i * 0.05}>
              <ProjectCard project={project} />
            </FadeIn>
          ))}
        </div>

        <div className="mt-10 flex flex-wrap items-center gap-3">
          {rest.length > 3 ? (
            <button
              onClick={() => setShowAll((v) => !v)}
              className="rounded-full border border-border bg-background px-5 py-3 text-sm font-semibold text-foreground transition-colors hover:bg-secondary"
            >
              {showAll ? "Show fewer projects" : `Show ${rest.length - 3} more projects`}
            </button>
          ) : null}
          <a
            href={SITE.github}
            target="_blank"
            rel="noreferrer noopener"
            className="inline-flex items-center gap-1.5 rounded-full bg-accent-ink px-5 py-3 text-sm font-semibold text-white transition-opacity hover:opacity-90"
          >
            View All Projects
            <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
          </a>
        </div>
      </div>
    </section>
  );
}
