import { FUTURE_WORK } from "@/data/portfolio";
import { FadeIn } from "./FadeIn";

export function FutureWorkSection() {
  return (
    <section id="future" className="border-b border-border bg-secondary/30 py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <FadeIn>
          <p className="section-eyebrow">Next</p>
          <h2 className="mt-4 font-display text-3xl font-black tracking-tight text-foreground sm:text-4xl lg:text-5xl">
            Future Work
          </h2>
          <p className="mt-4 max-w-2xl text-[15px] leading-relaxed text-muted-foreground">
            Exploring new projects in Machine Learning, Artificial Intelligence, Data
            Science, and applied AI systems. Future work will include additional ML
            experiments, AI applications, research projects, and capstone work.
          </p>
        </FadeIn>

        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {FUTURE_WORK.map((item, i) => (
            <FadeIn key={item.title} delay={i * 0.05}>
              <div className="h-full rounded-2xl border border-dashed border-border bg-background p-6">
                <span className="inline-flex rounded-full bg-secondary px-3 py-1 text-[10px] font-bold uppercase tracking-[0.16em] text-muted-foreground">
                  Coming Soon
                </span>
                <h3 className="mt-4 font-display text-lg font-bold tracking-tight text-foreground">
                  {item.title}
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  {item.description}
                </p>
              </div>
            </FadeIn>
          ))}
        </div>
      </div>
    </section>
  );
}
