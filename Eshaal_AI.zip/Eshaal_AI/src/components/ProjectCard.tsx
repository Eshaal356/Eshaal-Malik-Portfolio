import { useState } from "react";
import { ArrowUpRight, Github } from "lucide-react";
import type { Project } from "@/data/portfolio";

interface ProjectCardProps {
  project: Project;
  featured?: boolean;
}

export function ProjectCard({ project, featured = false }: ProjectCardProps) {
  const [expanded, setExpanded] = useState(false);
  const hasDetails = Boolean(project.details?.length);

  return (
    <article
      className={`group relative flex flex-col overflow-hidden rounded-3xl border border-border bg-background transition-all duration-300 hover:-translate-y-1 hover:border-foreground/25 hover:shadow-[0_24px_60px_-30px_rgba(12,12,12,0.45)] ${
        featured ? "lg:flex-row" : ""
      }`}
    >
      <div
        className={`relative flex items-center justify-center overflow-hidden bg-hero ${
          project.image ? "" : "px-6 py-10"
        } ${featured ? "lg:w-2/5" : ""} ${!project.image && featured ? "lg:py-16" : ""}`}
      >
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(187,204,215,0.18),transparent_55%)]" />
        {project.image ? (
          <img
            src={project.image}
            alt={project.imageAlt ?? project.name}
            loading="lazy"
            className={`h-full w-full object-contain transition-transform duration-700 group-hover:scale-[1.03] ${
              featured ? "aspect-[16/10] lg:aspect-auto lg:min-h-[340px]" : "aspect-[16/10]"
            }`}
          />
        ) : (
          <span className="hero-heading relative font-display text-6xl font-black leading-none tracking-tight lg:text-7xl">
            {project.index}
          </span>
        )}
        <span
          aria-hidden="true"
          className="absolute left-4 top-4 rounded-full bg-background/85 px-2.5 py-1 font-display text-xs font-bold tracking-[0.14em] text-foreground backdrop-blur"
        >
          {project.index}
        </span>
      </div>


      <div className={`flex flex-1 flex-col p-6 sm:p-8 ${featured ? "lg:p-10" : ""}`}>
        <h3
          className={`font-display font-bold tracking-tight text-foreground ${
            featured ? "text-2xl lg:text-3xl" : "text-xl"
          }`}
        >
          {project.name}
        </h3>
        <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
          {project.description}
        </p>

        {project.result ? (
          <p className="mt-4 inline-flex w-fit rounded-full bg-secondary px-3 py-1 text-xs font-semibold text-foreground">
            {project.result}
          </p>
        ) : null}

        {hasDetails ? (
          <>
            <button
              onClick={() => setExpanded((v) => !v)}
              aria-expanded={expanded}
              className="mt-4 w-fit text-xs font-semibold uppercase tracking-[0.16em] text-accent-ink underline-offset-4 hover:underline"
            >
              {expanded ? "Hide details" : "View details"}
            </button>
            {expanded ? (
              <ul className="mt-3 space-y-1.5 text-sm text-muted-foreground">
                {project.details!.map((d) => (
                  <li key={d} className="flex gap-2">
                    <span aria-hidden="true" className="text-accent-ink">
                      ▸
                    </span>
                    <span>{d}</span>
                  </li>
                ))}
              </ul>
            ) : null}
          </>
        ) : null}

        <ul className="mt-6 flex flex-wrap gap-2">
          {project.tech.map((t) => (
            <li key={t} className="badge">
              {t}
            </li>
          ))}
        </ul>

        <div className="mt-7 flex flex-wrap items-center gap-3 pt-1">
          {project.live ? (
            <a
              href={project.live}
              target="_blank"
              rel="noreferrer noopener"
              className="inline-flex items-center gap-1.5 rounded-full bg-accent-ink px-4 py-2.5 text-[13px] font-semibold text-white transition-opacity hover:opacity-90"
            >
              View Project
              <ArrowUpRight className="h-3.5 w-3.5" aria-hidden="true" />
            </a>
          ) : null}
          <a
            href={project.github}
            target="_blank"
            rel="noreferrer noopener"
            className="inline-flex items-center gap-1.5 rounded-full border border-border px-4 py-2.5 text-[13px] font-semibold text-foreground transition-colors hover:bg-secondary"
          >
            <Github className="h-3.5 w-3.5" aria-hidden="true" />
            GitHub
            <ArrowUpRight className="h-3.5 w-3.5" aria-hidden="true" />
          </a>
        </div>
      </div>
    </article>
  );
}
