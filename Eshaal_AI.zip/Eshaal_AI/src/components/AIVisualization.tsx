import neuralAsset from "@/assets/neural-3d.png.asset.json";

/**
 * Neural-network visualization: the rendered black-and-white neural artwork
 * drifts and rotates slowly in 3D space. Motion is disabled for users who
 * prefer reduced motion.
 */
export function AIVisualization() {
  return (
    <div
      role="img"
      aria-label="Layered neural network diagram of nodes joined by thin wires, drifting and rotating slowly in 3D."
      className="relative h-[240px] w-full overflow-hidden rounded-2xl bg-hero [perspective:1200px] sm:h-[300px] lg:h-[380px]"
    >
      <img
        src={neuralAsset.url}
        alt=""
        aria-hidden="true"
        loading="lazy"
        className="neural-drift absolute inset-0 h-full w-full object-cover"
      />
    </div>
  );
}
