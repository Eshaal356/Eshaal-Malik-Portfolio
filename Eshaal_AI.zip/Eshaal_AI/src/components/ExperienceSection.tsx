import { EXPERIENCE } from "@/data/portfolio";
import { FadeIn } from "./FadeIn";

export function ExperienceSection() {
  return (
    <section
      id="experience"
      className="border-b border-border bg-secondary/30 py-24 lg:py-32"
    >
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <FadeIn>
          <p className="section-eyebrow">Experience</p>
          <h2 className="mt-4 font-display text-3xl font-black tracking-tight text-foreground sm:text-4xl lg:text-5xl">
            Internships
          </h2>
        </FadeIn>

        <ol className="mt-12 border-l border-border pl-6 sm:pl-10">
          {EXPERIENCE.map((item, i) => (
            <li key={item.company} className="relative pb-12 last:pb-0">
              <span
                aria-hidden="true"
                className="absolute -left-[31px] top-1.5 h-3 w-3 rounded-full border-2 border-background bg-accent-ink sm:-left-[47px]"
              />
              <FadeIn delay={i * 0.05}>
                <h3 className="font-display text-lg font-bold uppercase tracking-tight text-foreground sm:text-xl">
                  {item.role} — {item.company}
                </h3>
                <p className="mt-1 text-xs font-medium uppercase tracking-[0.16em] text-muted-foreground">
                  {item.status}
                </p>
                <ul className="mt-4 space-y-2 text-sm leading-relaxed text-muted-foreground">
                  {item.points.map((p) => (
                    <li key={p} className="flex gap-2">
                      <span aria-hidden="true" className="text-accent-ink">
                        ▸
                      </span>
                      <span>{p}</span>
                    </li>
                  ))}
                </ul>
              </FadeIn>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
