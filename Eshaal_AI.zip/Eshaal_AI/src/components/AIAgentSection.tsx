import { useEffect, useRef, useState } from "react";
import { Send, Bot, User, ShieldCheck } from "lucide-react";
import { AI_SUGGESTED_QUESTIONS } from "@/data/portfolio";
import { answerQuestion } from "@/lib/eshaal-ai";
import { FadeIn } from "./FadeIn";

interface Message {
  id: string;
  role: "user" | "assistant";
  text: string;
}

const GREETING: Message = {
  id: "greeting",
  role: "assistant",
  text: "Hi — I'm Eshaal AI. I answer using verified information from this portfolio only. Ask about Eshaal's projects, skills, internships, certifications, or how to get in touch.",
};

export function AIAgentSection() {
  const [messages, setMessages] = useState<Message[]>([GREETING]);
  const [input, setInput] = useState("");
  const [typing, setTyping] = useState(false);
  const listRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, typing]);

  const ask = (question: string) => {
    const text = question.trim();
    if (!text || typing) return;
    setMessages((m) => [...m, { id: `u-${Date.now()}`, role: "user", text }]);
    setInput("");
    setTyping(true);
    window.setTimeout(() => {
      setMessages((m) => [
        ...m,
        { id: `a-${Date.now()}`, role: "assistant", text: answerQuestion(text) },
      ]);
      setTyping(false);
      inputRef.current?.focus();
    }, 550);
  };

  return (
    <section id="ai-agent" className="border-b border-border bg-hero py-24 lg:py-32">
      <div className="mx-auto max-w-5xl px-5 lg:px-8">
        <FadeIn>
          <p className="text-xs font-bold uppercase tracking-[0.22em] text-white/45">
            Assistant
          </p>
          <h2 className="mt-4 font-display text-3xl font-black tracking-tight text-white sm:text-4xl lg:text-5xl">
            Eshaal AI
          </h2>
          <p className="mt-3 font-display text-lg text-white/70">Ask about my work</p>
          <p className="mt-4 max-w-2xl text-[15px] leading-relaxed text-white/60">
            Eshaal AI is a personal AI assistant that answers questions using verified
            portfolio information. It clearly states when information is unavailable
            rather than guessing.
          </p>
        </FadeIn>

        <FadeIn delay={0.1}>
          <div className="mt-10 overflow-hidden rounded-3xl border border-white/12 bg-white/[0.03]">
            <div className="flex items-center gap-2 border-b border-white/10 px-5 py-3.5">
              <span className="flex h-7 w-7 items-center justify-center rounded-full bg-white/10">
                <Bot className="h-3.5 w-3.5 text-white" aria-hidden="true" />
              </span>
              <span className="font-display text-sm font-bold tracking-tight text-white">
                Eshaal AI
              </span>
              <span className="ml-auto inline-flex items-center gap-1.5 text-[11px] font-medium text-white/45">
                <ShieldCheck className="h-3 w-3" aria-hidden="true" />
                Verified portfolio data only
              </span>
            </div>

            <div
              ref={listRef}
              role="log"
              aria-live="polite"
              aria-label="Conversation with Eshaal AI"
              className="h-[360px] space-y-4 overflow-y-auto px-5 py-6"
            >
              {messages.map((m) => (
                <div
                  key={m.id}
                  className={`flex gap-3 ${m.role === "user" ? "justify-end" : ""}`}
                >
                  {m.role === "assistant" ? (
                    <span className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-white/10">
                      <Bot className="h-3.5 w-3.5 text-white/80" aria-hidden="true" />
                    </span>
                  ) : null}
                  <p
                    className={`max-w-[80%] whitespace-pre-wrap rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                      m.role === "user"
                        ? "bg-white text-hero"
                        : "bg-white/[0.06] text-white/80"
                    }`}
                  >
                    {m.text}
                  </p>
                  {m.role === "user" ? (
                    <span className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-white/10">
                      <User className="h-3.5 w-3.5 text-white/80" aria-hidden="true" />
                    </span>
                  ) : null}
                </div>
              ))}

              {typing ? (
                <div className="flex gap-3">
                  <span className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-white/10">
                    <Bot className="h-3.5 w-3.5 text-white/80" aria-hidden="true" />
                  </span>
                  <span className="flex items-center gap-1 rounded-2xl bg-white/[0.06] px-4 py-4">
                    <span className="sr-only">Eshaal AI is typing</span>
                    {[0, 1, 2].map((i) => (
                      <span
                        key={i}
                        className="h-1.5 w-1.5 animate-pulse rounded-full bg-white/60"
                        style={{ animationDelay: `${i * 0.15}s` }}
                      />
                    ))}
                  </span>
                </div>
              ) : null}
            </div>

            <div className="border-t border-white/10 px-5 py-4">
              <ul className="mb-3 flex flex-wrap gap-2">
                {AI_SUGGESTED_QUESTIONS.map((q) => (
                  <li key={q}>
                    <button
                      onClick={() => ask(q)}
                      className="rounded-full border border-white/15 px-3 py-1.5 text-[12px] text-white/70 transition-colors hover:bg-white/10 hover:text-white"
                    >
                      {q}
                    </button>
                  </li>
                ))}
              </ul>
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  ask(input);
                }}
                className="flex items-center gap-2"
              >
                <label htmlFor="eshaal-ai-input" className="sr-only">
                  Ask Eshaal AI a question
                </label>
                <input
                  id="eshaal-ai-input"
                  ref={inputRef}
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Ask about Eshaal's work…"
                  className="h-11 flex-1 rounded-full border border-white/15 bg-white/[0.04] px-4 text-sm text-white placeholder:text-white/35 focus:border-white/40 focus:outline-none focus-visible:ring-2 focus-visible:ring-white/30"
                />
                <button
                  type="submit"
                  disabled={typing || !input.trim()}
                  aria-label="Send question"
                  className="inline-flex h-11 w-11 items-center justify-center rounded-full bg-white text-hero transition-opacity disabled:opacity-40"
                >
                  <Send className="h-4 w-4" aria-hidden="true" />
                </button>
              </form>
            </div>
          </div>
          <p className="mt-3 text-xs text-white/40">
            Runs locally on this site&apos;s verified content — no external model is
            connected yet.
          </p>
        </FadeIn>
      </div>
    </section>
  );
}
