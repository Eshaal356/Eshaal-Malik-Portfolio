import { Download, Github, Linkedin, Mail, MapPin } from "lucide-react";
import { SITE } from "@/data/portfolio";
import { FadeIn } from "./FadeIn";
import { ContactButton } from "./ContactButton";

export function ContactSection() {
  return (
    <section id="contact" className="bg-background py-24 lg:py-32">
      <div className="mx-auto max-w-4xl px-5 text-center lg:px-8">
        <FadeIn>
          <p className="section-eyebrow">Contact</p>
          <h2 className="mt-4 font-display text-4xl font-black tracking-tight text-foreground sm:text-5xl lg:text-6xl">
            Get in touch
          </h2>
          <p className="mx-auto mt-5 max-w-xl text-[15px] leading-relaxed text-muted-foreground">
            Have an AI or Machine Learning project in mind? Let&apos;s connect.
          </p>

          <a
            href={`mailto:${SITE.email}`}
            className="mt-8 inline-flex items-center gap-2 font-display text-lg font-bold tracking-tight text-foreground underline-offset-8 hover:underline sm:text-2xl"
          >
            <Mail className="h-5 w-5" aria-hidden="true" />
            {SITE.email}
          </a>

          <p className="mt-3 flex items-center justify-center gap-1.5 text-sm text-muted-foreground">
            <MapPin className="h-4 w-4" aria-hidden="true" />
            {SITE.location}
          </p>

          <div className="mt-10 flex flex-wrap items-center justify-center gap-3">
            <a
              href={SITE.github}
              target="_blank"
              rel="noreferrer noopener"
              className="inline-flex items-center gap-2 rounded-full bg-accent-ink px-5 py-3 text-sm font-semibold text-white transition-opacity hover:opacity-90"
            >
              <Github className="h-4 w-4" aria-hidden="true" />
              GitHub
            </a>
            <a
              href={SITE.linkedin}
              target="_blank"
              rel="noreferrer noopener"
              className="inline-flex items-center gap-2 rounded-full border border-border px-5 py-3 text-sm font-semibold text-foreground transition-colors hover:bg-secondary"
            >
              <Linkedin className="h-4 w-4" aria-hidden="true" />
              LinkedIn
            </a>
            <a
              href={SITE.cv}
              download
              className="inline-flex items-center gap-2 rounded-full border border-border px-5 py-3 text-sm font-semibold text-foreground transition-colors hover:bg-secondary"
            >
              <Download className="h-4 w-4" aria-hidden="true" />
              Download CV
            </a>
            <ContactButton />
          </div>
        </FadeIn>
      </div>
    </section>
  );
}
