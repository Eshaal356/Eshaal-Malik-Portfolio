import { useEffect, useState } from "react";
import { Menu, X, Download } from "lucide-react";
import { NAV_ITEMS, SITE } from "@/data/portfolio";

function scrollToSection(id: string) {
  const el = document.getElementById(id);
  if (!el) return;
  el.scrollIntoView({ behavior: "smooth", block: "start" });
}

export function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [active, setActive] = useState<string>("");

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible) setActive(visible.target.id);
      },
      { rootMargin: "-40% 0px -50% 0px", threshold: [0.1, 0.5] },
    );
    NAV_ITEMS.forEach(({ id }) => {
      const el = document.getElementById(id);
      if (el) observer.observe(el);
    });
    return () => observer.disconnect();
  }, []);

  const go = (id: string) => {
    setOpen(false);
    scrollToSection(id);
  };

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-colors duration-300 ${
        scrolled
          ? "border-b border-border/70 bg-background/85 backdrop-blur-xl"
          : "border-b border-transparent bg-transparent"
      }`}
    >
      <nav
        aria-label="Main navigation"
        className="mx-auto flex h-16 max-w-7xl items-center justify-between px-5 lg:px-8"
      >
        <button
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          className={`font-display text-sm font-black uppercase tracking-[0.18em] transition-colors ${
            scrolled ? "text-foreground" : "text-white"
          }`}
        >
          Eshaal Malik
        </button>

        <ul className="hidden items-center gap-1 lg:flex">
          {NAV_ITEMS.map((item) => (
            <li key={item.id}>
              <button
                onClick={() => go(item.id)}
                aria-current={active === item.id ? "true" : undefined}
                className={`rounded-full px-3 py-2 text-[13px] font-medium transition-colors ${
                  scrolled
                    ? active === item.id
                      ? "bg-secondary text-foreground"
                      : "text-muted-foreground hover:text-foreground"
                    : active === item.id
                      ? "bg-white/15 text-white"
                      : "text-white/70 hover:text-white"
                }`}
              >
                {item.label}
              </button>
            </li>
          ))}
        </ul>

        <div className="hidden items-center gap-2 lg:flex">
          <button
            onClick={() => go("ai-agent")}
            className="rounded-full bg-accent-ink px-4 py-2 text-[13px] font-semibold text-white transition-opacity hover:opacity-90"
          >
            Try Eshaal AI
          </button>
          <a
            href={SITE.cv}
            download
            className={`inline-flex items-center gap-1.5 rounded-full border px-4 py-2 text-[13px] font-semibold transition-colors ${
              scrolled
                ? "border-border text-foreground hover:bg-secondary"
                : "border-white/30 text-white hover:bg-white/10"
            }`}
          >
            <Download className="h-3.5 w-3.5" aria-hidden="true" />
            Download CV
          </a>
        </div>

        <button
          onClick={() => setOpen((v) => !v)}
          aria-expanded={open}
          aria-label={open ? "Close menu" : "Open menu"}
          className={`inline-flex h-11 w-11 items-center justify-center rounded-full lg:hidden ${
            scrolled ? "text-foreground" : "text-white"
          }`}
        >
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </nav>

      {open ? (
        <div className="fixed inset-0 z-50 bg-background lg:hidden">
          <div className="flex h-16 items-center justify-between px-5">
            <span className="font-display text-sm font-black uppercase tracking-[0.18em]">
              Eshaal Malik
            </span>
            <button
              onClick={() => setOpen(false)}
              aria-label="Close menu"
              className="inline-flex h-11 w-11 items-center justify-center rounded-full text-foreground"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
          <ul className="flex flex-col gap-1 px-5 pt-4">
            {NAV_ITEMS.map((item) => (
              <li key={item.id}>
                <button
                  onClick={() => go(item.id)}
                  className="w-full border-b border-border py-4 text-left font-display text-2xl font-bold tracking-tight text-foreground"
                >
                  {item.label}
                </button>
              </li>
            ))}
          </ul>
          <div className="flex flex-col gap-3 px-5 pt-8">
            <button
              onClick={() => go("ai-agent")}
              className="rounded-full bg-accent-ink px-5 py-3 text-sm font-semibold text-white"
            >
              Try Eshaal AI
            </button>
            <a
              href={SITE.cv}
              download
              className="rounded-full border border-border px-5 py-3 text-center text-sm font-semibold text-foreground"
            >
              Download CV
            </a>
          </div>
        </div>
      ) : null}
    </header>
  );
}
