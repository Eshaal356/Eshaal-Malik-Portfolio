import { FadeIn } from "./FadeIn";
import { AIVisualization } from "./AIVisualization";
import { EDUCATION } from "@/data/portfolio";

const FOCUS = [
  "Generative AI",
  "AI Agents",
  "Applied Data Science",
  "Computer Vision",
  "Machine Learning",
];

export function AboutSection() {
  return (
    <section id="about" className="border-b border-border bg-background py-24 lg:py-32">
      <div className="mx-auto grid max-w-7xl gap-14 px-5 lg:grid-cols-2 lg:items-center lg:gap-20 lg:px-8">
        <FadeIn>
          <p className="section-eyebrow">About</p>
          <h2 className="mt-4 font-display text-3xl font-black leading-[1.1] tracking-tight text-foreground sm:text-4xl lg:text-5xl">
            A practical approach to AI and machine learning
          </h2>
          <div className="mt-6 space-y-5 text-[15px] leading-relaxed text-muted-foreground">
            <p>
              Eshaal Malik is an Intermediate Computer Science student focused on Python,
              Machine Learning, Data Science, and Artificial Intelligence.
            </p>
            <p>
              Her interest is in building practical AI applications and machine-learning
              systems — taking problems from data preparation and feature engineering
              through to trained models and usable interfaces.
            </p>
          </div>

          <ul className="mt-7 flex flex-wrap gap-2">
            {FOCUS.map((item) => (
              <li key={item} className="badge">
                {item}
              </li>
            ))}
          </ul>

          <div className="mt-10 rounded-2xl border border-border p-6">
            <p className="section-eyebrow">Education</p>
            <h3 className="mt-3 font-display text-lg font-bold text-foreground">
              {EDUCATION.qualification}
            </h3>
            <p className="text-sm text-muted-foreground">{EDUCATION.institution}</p>
            <p className="mt-1 text-xs font-medium uppercase tracking-[0.16em] text-accent-ink">
              {EDUCATION.status}
            </p>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
              {EDUCATION.description}
            </p>
          </div>
        </FadeIn>

        <FadeIn delay={0.15}>
          <div className="rounded-3xl border border-border bg-secondary/40 p-4 sm:p-8">
            <AIVisualization />
            <p className="mt-4 text-center text-xs text-muted-foreground">
              Neural network structure — layered nodes and connections, the shape behind
              most of the models in this portfolio.
            </p>
          </div>
        </FadeIn>
      </div>
    </section>
  );
}
