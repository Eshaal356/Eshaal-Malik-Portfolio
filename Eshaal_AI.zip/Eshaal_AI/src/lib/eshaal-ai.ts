import {
  PROJECTS,
  SITE,
  SKILLS,
  EXPERIENCE,
  CERTIFICATIONS,
  EDUCATION,
} from "@/data/portfolio";

export const NO_ANSWER = "I don't have verified information about that.";

interface Entry {
  keywords: string[];
  answer: () => string;
}

/**
 * Eshaal AI runs entirely on the verified portfolio data in `portfolio.ts`.
 * It never generates new facts — when nothing matches, it says so.
 * To connect a real model later, replace `answerQuestion` with a server call
 * that is grounded on this same dataset.
 */
const ENTRIES: Entry[] = [
  {
    keywords: ["who", "about", "eshaal is", "yourself", "introduce", "bio"],
    answer: () =>
      `${SITE.name} is an ${SITE.title.toLowerCase()} based in ${SITE.location}. She is an Intermediate Computer Science student focused on Python, Machine Learning, Data Science, and Artificial Intelligence, building practical AI applications from data preparation and feature engineering through to trained models and usable interfaces.`,
  },
  {
    keywords: ["google search", "ranking", "discoverability", "flyrank"],
    answer: () => {
      const p = PROJECTS[0]!;
      return `${p.name}: ${p.description} Technologies: ${p.tech.join(", ")}. Live project: ${p.live}`;
    },
  },
  {
    keywords: ["aqi", "air quality", "forecast", "accuracy", "pollution"],
    answer: () => {
      const p = PROJECTS.find((x) => x.id === "aqi-pak")!;
      return `${p.name}: ${p.description}\n\n${p.details!.map((d) => `• ${d}`).join("\n")}\n\nVerified result: ${p.result}. GitHub: ${p.github}`;
    },
  },
  {
    keywords: ["project", "built", "work", "portfolio", "repos"],
    answer: () =>
      `Eshaal has ${PROJECTS.length} documented projects:\n\n${PROJECTS.map(
        (p) => `${p.index}. ${p.name} — ${p.tech.slice(0, 3).join(", ")}`,
      ).join("\n")}\n\nAsk about any one of them by name for more detail.`,
  },
  {
    keywords: ["technolog", "tools", "skill", "stack", "language", "framework", "library"],
    answer: () =>
      `Tools and techniques:\n\n${SKILLS.map(
        (s) => `${s.title}: ${s.items.join(", ")}`,
      ).join("\n\n")}`,
  },
  {
    keywords: ["internship", "experience", "job", "worked", "employ"],
    answer: () =>
      `Eshaal has completed four remote internships:\n\n${EXPERIENCE.map(
        (e) => `• ${e.role} — ${e.company} (${e.status})`,
      ).join("\n")}`,
  },
  {
    keywords: ["certification", "certificate", "course", "training", "anthropic", "claude"],
    answer: () =>
      CERTIFICATIONS.map((g) => `${g.title}:\n${g.items.map((i) => `• ${i}`).join("\n")}`).join(
        "\n\n",
      ),
  },
  {
    keywords: ["contact", "email", "reach", "hire", "linkedin", "github", "cv", "resume"],
    answer: () =>
      `You can reach Eshaal at ${SITE.email}. GitHub: ${SITE.github}. LinkedIn: ${SITE.linkedin}. Her CV is available from the Download CV button on this site.`,
  },
  {
    keywords: ["education", "study", "college", "school", "degree", "student"],
    answer: () =>
      `${EDUCATION.qualification} at ${EDUCATION.institution} — ${EDUCATION.status}. ${EDUCATION.description}`,
  },
  {
    keywords: ["location", "based", "karachi", "where"],
    answer: () => `Eshaal is based in ${SITE.location}.`,
  },
];

export function answerQuestion(question: string): string {
  const q = question.toLowerCase().trim();
  if (!q) return NO_ANSWER;

  const byName = PROJECTS.find((p) => q.includes(p.name.split(" —")[0]!.toLowerCase()));
  if (byName) {
    const detail = byName.details ? `\n\n${byName.details.map((d) => `• ${d}`).join("\n")}` : "";
    const live = byName.live ? `\nLive: ${byName.live}` : "";
    return `${byName.name}: ${byName.description}${detail}\n\nTechnologies: ${byName.tech.join(
      ", ",
    )}${live}\nGitHub: ${byName.github}`;
  }

  let best: { score: number; entry: Entry } | null = null;
  for (const entry of ENTRIES) {
    const score = entry.keywords.filter((k) => q.includes(k)).length;
    if (score > 0 && (!best || score > best.score)) best = { score, entry };
  }

  return best ? best.entry.answer() : NO_ANSWER;
}
